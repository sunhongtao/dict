#coding:utf-8
'''
Created on 2016年6月3日

@author: 1811
'''
from distutils.core import setup

setup(
    name = "dict",
    version = "1.0.1",
    py_modules = ['dict'],
    author = 'Hunter',
    descripton = 'Translate English or Chinese',
    )